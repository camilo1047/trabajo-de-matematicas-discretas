extends Node

# ── Variables ─────────────────────────────────────────
var edificios_dañados: Array = []

# ── Registrar edificio dañado ─────────────────────────
func registrar_daño(edificio) -> void:
	if not edificios_dañados.has(edificio):
		edificios_dañados.append(edificio)
		print("sys_reparacion — edificio dañado registrado: " + edificio.nombre)

# ── Reparar edificio ──────────────────────────────────
func reparar_edificio(edificio) -> bool:
	if not edificios_dañados.has(edificio):
		return false
	if edificio.reparar():
		edificios_dañados.erase(edificio)
		print("sys_reparacion — edificio reparado: " + edificio.nombre)
		return true
	print("sys_reparacion — no hay recursos para reparar: " + edificio.nombre)
	return false

# ── Consultar edificios dañados ───────────────────────
func obtener_dañados() -> Array:
	return edificios_dañados

# ── Consultar estado ──────────────────────────────────
func obtener_estado() -> String:
	return "Reparación — Edificios dañados: " + str(edificios_dañados.size())
