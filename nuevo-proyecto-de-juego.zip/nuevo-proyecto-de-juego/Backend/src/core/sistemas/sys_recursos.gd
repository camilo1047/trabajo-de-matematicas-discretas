# res://src/core/sistemas/sys_recursos.gd
extends Node

# ── Recursos ───────────────────────────────────────────────────────
var dinero: int = 500
var materiales: int = 100
var poblacion: int = 0
var poblacion_maxima: int = 0

# ── Señales ────────────────────────────────────────────────────────
signal dinero_cambiado(nuevo: int)
signal materiales_cambiado(nuevo: int)
signal poblacion_cambiada(nueva: int)
signal sin_dinero
signal sin_materiales

# ── Dinero ─────────────────────────────────────────────────────────
func agregar_dinero(cantidad: int) -> void:
	dinero += cantidad
	emit_signal("dinero_cambiado", dinero)

func gastar_dinero(cantidad: int) -> bool:
	if dinero < cantidad:
		emit_signal("sin_dinero")
		return false
	dinero -= cantidad
	emit_signal("dinero_cambiado", dinero)
	return true

# ── Materiales ─────────────────────────────────────────────────────
func agregar_materiales(cantidad: int) -> void:
	materiales += cantidad
	emit_signal("materiales_cambiado", materiales)

func gastar_materiales(cantidad: int) -> bool:
	if materiales < cantidad:
		emit_signal("sin_materiales")
		return false
	materiales -= cantidad
	emit_signal("materiales_cambiado", materiales)
	return true

# ── Población ──────────────────────────────────────────────────────
func actualizar_poblacion(delta: int) -> void:
	poblacion = clamp(poblacion + delta, 0, poblacion_maxima)
	emit_signal("poblacion_cambiada", poblacion)

func actualizar_poblacion_maxima(delta: int) -> void:
	poblacion_maxima = max(0, poblacion_maxima + delta)

# ── Serialización (para SysGuardado) ──────────────────────────────
func obtener_datos() -> Dictionary:
	return {
		"dinero": dinero,
		"materiales": materiales,
		"poblacion": poblacion,
		"poblacion_maxima": poblacion_maxima
	}

func cargar_datos(datos: Dictionary) -> void:
	dinero           = datos.get("dinero", 500)
	materiales       = datos.get("materiales", 100)
	poblacion        = datos.get("poblacion", 0)
	poblacion_maxima = datos.get("poblacion_maxima", 0)
	emit_signal("dinero_cambiado", dinero)
	emit_signal("materiales_cambiado", materiales)
	emit_signal("poblacion_cambiada", poblacion)
