extends Node

# ── Variables ─────────────────────────────────────────
var vehiculos_activos: Array = []
var max_vehiculos: int = 0
var tiempo_aparicion: float = 120.0
var tiempo_acumulado: float = 0.0

# ── Actualizar cada frame ─────────────────────────────
func _process(delta: float) -> void:
	tiempo_acumulado += delta
	if tiempo_acumulado >= tiempo_aparicion:
		tiempo_acumulado = 0.0
		intentar_agregar_vehiculo()

# ── Calcular máximo de vehículos ──────────────────────
func calcular_max_vehiculos() -> void:
	var casas = get_tree().get_nodes_in_group("casas")
	max_vehiculos = 0
	for casa in casas:
		match casa.tipo:
			0: max_vehiculos += 1  # pequeña
			1: max_vehiculos += 1  # mediana
			2: max_vehiculos += 2  # grande
	print("sys_trafico — máximo vehículos: " + str(max_vehiculos))

# ── Intentar agregar vehículo ─────────────────────────
func intentar_agregar_vehiculo() -> void:
	calcular_max_vehiculos()
	if vehiculos_activos.size() >= max_vehiculos:
		return
	agregar_vehiculo_aleatorio()

# ── Agregar vehículo aleatorio ────────────────────────
func agregar_vehiculo_aleatorio() -> void:
	var tipo_vehiculo = randi() % 3
	match tipo_vehiculo:
		0: agregar_auto()
		1: agregar_bicicleta()
		2: agregar_auto()

# ── Agregar auto ──────────────────────────────────────
func agregar_auto() -> void:
	var auto = load("res://Backend/src/core/objectos/vehiculos/obj_automoviles.gd").new()
	var tipo_auto = randi() % 5
	auto.iniciar(tipo_auto)
	add_child(auto)
	auto.add_to_group("vehiculos")
	vehiculos_activos.append(auto)
	print("sys_trafico — nuevo auto: " + auto.nombre)

# ── Agregar bicicleta ─────────────────────────────────
func agregar_bicicleta() -> void:
	var casas_validas = get_tree().get_nodes_in_group("casas").filter(
		func(c): return c.tipo == 0 or c.tipo == 1
	)
	if casas_validas.size() == 0:
		return
	var bici = load("res://Backend/src/core/objectos/vehiculos/obj_bicicleta.gd").new()
	var tipo_bici = randi() % 5
	bici.iniciar(tipo_bici)
	add_child(bici)
	bici.add_to_group("vehiculos")
	vehiculos_activos.append(bici)
	print("sys_trafico — nueva bicicleta: " + bici.nombre)

# ── Remover vehículo ──────────────────────────────────
func remover_vehiculo(vehiculo) -> void:
	vehiculos_activos.erase(vehiculo)
	print("sys_trafico — vehículo removido | activos: " + str(vehiculos_activos.size()))

# ── Consultar estado ──────────────────────────────────
func obtener_estado() -> String:
	return "Tráfico — Vehículos: " + str(vehiculos_activos.size()) + "/" + str(max_vehiculos)
